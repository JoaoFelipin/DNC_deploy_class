# Create Python environment

```bash
conda create -n ml python=3.8
conda activate ml
pip install -r requirements.txt
```
